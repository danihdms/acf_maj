# Indicate

## Déploiement
![Deploy do Azure AppService](https://github.com/acf-france/Indicate/workflows/Deploy%20do%20Azure%20AppService/badge.svg?branch=master)

La branche principale (master) est déployé à chaques commit sur le serveur : https://acf-indicate.azurewebsites.net
