<nav class="site-header sticky-top py-1">

<div class="container d-flex flex-column flex-md-row justify-content-between">
    <a href="index.php"><img src="public/Images/logowhite.png" alt="logoACF" id="logoACF" /></a>
    <a class="optionMenu" href="index.php" id="page0"><?php echo menu_0 ?></a>
    <a class="optionMenu" href="MnE.php" id="page1"> <?php echo menu_1 ?></a>
    <a class="optionMenu" href="indicateurs.php" id="page2"> <?php echo menu_2 ?></a>
    <a class="optionMenu" href="questionnaire.php" id="page3"> <?php echo menu_3 ?></a>

</div>

<style type="text/css">
#choix_langue{
  float: right;
  margin: 10px;
}
</style>

<?php
// Le menu de sélection de la langue reste sur la langue utilisée
if ($_SESSION['lang'] == 'fr'){
  $select_fr = "selected";
  $select_en = "";
}
else if ($_SESSION['lang'] == 'en'){
  $select_fr = "";
  $select_en = "selected";
}
 ?>

<form id="choix_langue" action="traitement_langues.php" method="post">

<select name="langue">
    <option value="1" <?php echo $select_fr ?>>Français</option>
    <option value="2" <?php echo $select_en ?>>English</option>
</select>
<input type="submit" value="OK">
</form>

</nav>
